/*
PROJECT 2 - Writer's Block
Let's create a simple program fhat will generate random story ideas to assist with writer's block!
Read the code and all of its comments. Follow the instructions contained in the comments to complete this project.
When finished, compress this project  into a ZIP folder and submit it to Canvas.
You MUST build and run your code in RELEASE mode to receive full credit.
*/

#include <iostream>
//Add the cstdlib, string.h, and vector lybraries. (4)

using namespace std;

int main(){
    //Create a vector of type int called ideas. (2)
    //This vector will contain all the random ideas entered by the user.

    //Create a string called newIdea. (2)
    //When the user chooses to enter a new idea, this string will be used to contain it and add it to ideas.

    //Create two integers called choice and randomIndex. (2)
    //choice will be used to select an option from the switch statement that serves as the bulk of this project.
    //randomIndex will be used to select the idea to pull from ideas.


    cout<< "Menu Options:\n\
            1 - Add New Idea\n\
            2 - Draw Random Idea\n\
            3 - View All Ideas\n\
            4 - Clear Idea List\n\
            0 - Exit\n";

    do{
        //Prompt the user to select an option. (2)

        //Create a switch statement that uses choice to select case. (8)
        //Case 1 allows the user to enter a new idea. (10)
        //Remember to use cin.ignore and getline for string input.
        //Case 2 generates a random idea from the ideas vector. (10)
        //If the vector is empty, case 2 should instead print a message stating this.
        //Case 3 prints the entire contents of the ideas vector. Each entry should be on its own line. (10)
        //You should also print the number of entries in the vector.
        //Case 4 deletes the contents of the ideas vector. (10)
        //Case 0 exits the program. (8)
        //Create a default case that notifies the user of their invalid selection. (8)

    }while(/*choice is not zero (4)*/);

    return 0;
}
